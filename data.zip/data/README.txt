Source:

http://www.elections.ca/content.aspx?section=res&dir=rep/off/42gedata&document=byed&lang=e#ON

Files were renamed for convenience